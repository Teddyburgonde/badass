Project: 'p1' created on 2026-01-16
Author: John Doe <john.doe@example.com>

No project description was given